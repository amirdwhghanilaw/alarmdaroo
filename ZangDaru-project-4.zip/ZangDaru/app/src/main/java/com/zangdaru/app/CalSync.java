package com.zangdaru.app;

import android.Manifest;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

/** Two-way link with the phone's own calendar (Google / Samsung / etc.). */
final class CalSync {
    /** Added to every event we write, so we can skip our own copies when reading the calendar back. */
    static final String MARK = "[زنگ دارو]";

    static boolean has(Context c) {
        return c.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
                && c.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED;
    }

    /** The phone's main writable calendar (the account's own calendar if possible), or -1. */
    static long calId(Context c) {
        if (!has(c)) return -1;
        long first = -1;
        try (Cursor cur = c.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI,
                new String[]{CalendarContract.Calendars._ID, CalendarContract.Calendars.ACCOUNT_NAME,
                        CalendarContract.Calendars.OWNER_ACCOUNT},
                CalendarContract.Calendars.VISIBLE + "=1 AND "
                        + CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + ">=" + CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR,
                null, null)) {
            if (cur == null) return -1;
            while (cur.moveToNext()) {
                long id = cur.getLong(0);
                if (first < 0) first = id;
                String acc = cur.getString(1), owner = cur.getString(2);
                if (acc != null && acc.equals(owner)) return id;
            }
        } catch (Exception e) {
            return -1;
        }
        return first;
    }

    private static ContentValues values(long cal, String title, String desc, long start, long end, boolean alarm) {
        ContentValues v = new ContentValues();
        v.put(CalendarContract.Events.CALENDAR_ID, cal);
        v.put(CalendarContract.Events.TITLE, title);
        v.put(CalendarContract.Events.DESCRIPTION, desc + "\n" + MARK);
        v.put(CalendarContract.Events.DTSTART, start);
        v.put(CalendarContract.Events.DTEND, end);
        v.put(CalendarContract.Events.ALL_DAY, 0);
        v.put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().getID());
        v.put(CalendarContract.Events.HAS_ALARM, alarm ? 1 : 0);
        return v;
    }

    private static ArrayList<Long> insertMany(Context c, ArrayList<ContentValues> list) {
        ArrayList<Long> ids = new ArrayList<>();
        for (int from = 0; from < list.size(); from += 50) {
            ArrayList<ContentProviderOperation> ops = new ArrayList<>();
            for (int i = from; i < Math.min(from + 50, list.size()); i++) {
                ops.add(ContentProviderOperation.newInsert(CalendarContract.Events.CONTENT_URI).withValues(list.get(i)).build());
            }
            try {
                ContentProviderResult[] r = c.getContentResolver().applyBatch(CalendarContract.AUTHORITY, ops);
                for (ContentProviderResult x : r) if (x.uri != null) ids.add(ContentUris.parseId(x.uri));
            } catch (Exception e) { /* keep what we have */ }
        }
        return ids;
    }

    static void deleteMany(Context c, List<Long> ids) {
        if (ids.isEmpty() || !has(c)) return;
        for (int from = 0; from < ids.size(); from += 50) {
            ArrayList<ContentProviderOperation> ops = new ArrayList<>();
            for (int i = from; i < Math.min(from + 50, ids.size()); i++) {
                ops.add(ContentProviderOperation.newDelete(
                        ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, ids.get(i))).build());
            }
            try {
                c.getContentResolver().applyBatch(CalendarContract.AUTHORITY, ops);
            } catch (Exception e) { /* already gone */ }
        }
    }

    static void delete(Context c, long id) {
        if (id < 0) return;
        ArrayList<Long> one = new ArrayList<>();
        one.add(id);
        deleteMany(c, one);
    }

    /** Doctor visit: one event with phone-calendar alerts 24 h and 2 h before. */
    static void syncAppt(Context c, Appt a) {
        delete(c, a.evId);
        a.evId = -1;
        long cal = calId(c);
        if (cal < 0) return;
        String desc = "پزشک: " + a.doctor + (a.note.isEmpty() ? "" : "\n" + a.note);
        long st = a.millis();
        ArrayList<ContentValues> one = new ArrayList<>();
        one.add(values(cal, "🩺 وقت پزشک: " + a.doctor, desc, st, st + 60 * 60 * 1000L, true));
        ArrayList<Long> ids = insertMany(c, one);
        if (ids.isEmpty()) return;
        a.evId = ids.get(0);
        int[] mins = {24 * 60, 2 * 60};
        for (int m : mins) {
            ContentValues r = new ContentValues();
            r.put(CalendarContract.Reminders.EVENT_ID, a.evId);
            r.put(CalendarContract.Reminders.MINUTES, m);
            r.put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT);
            try {
                c.getContentResolver().insert(CalendarContract.Reminders.CONTENT_URI, r);
            } catch (Exception e) { /* calendar may not allow reminders */ }
        }
    }

    /** Medicine: one phone-calendar event per day, from the first to the last time of that day. */
    static void syncMed(Context c, Med m) {
        deleteMany(c, m.evIds);
        m.evIds.clear();
        long cal = calId(c);
        if (cal < 0 || m.times.isEmpty()) return;
        ArrayList<String> ts = new ArrayList<>(m.times);
        Collections.sort(ts);
        String first = ts.get(0), last = ts.get(ts.size() - 1);
        StringBuilder d = new StringBuilder("ساعت‌های مصرف: ");
        for (int i = 0; i < ts.size(); i++) {
            if (i > 0) d.append("، ");
            d.append(Jalali.fa(ts.get(i)));
        }
        if (!m.note.isEmpty()) d.append("\n").append(m.note);
        ArrayList<ContentValues> list = new ArrayList<>();
        for (int k : m.dayKeys()) {
            long st = Jalali.millis(k, hour(first), minute(first));
            long en = Jalali.millis(k, hour(last), minute(last)) + 30 * 60000L;
            list.add(values(cal, "💊 " + m.name, d.toString(), st, en, false));
        }
        m.evIds.addAll(insertMany(c, list));
    }

    private static int hour(String t) { return Integer.parseInt(t.split(":")[0]); }
    private static int minute(String t) { return Integer.parseInt(t.split(":")[1]); }

    /** Re-writes everything to the phone calendar (used right after the permission is granted). */
    static void syncAll(Context c) {
        if (!has(c)) return;
        for (Med m : Store.all(c)) { syncMed(c, m); Store.save(c, m); }
        for (Appt a : Store.allAppts(c)) { syncAppt(c, a); Store.saveAppt(c, a); }
    }

    /** Run in the background on start-up: first time = full sync, later = only what is missing. */
    static void heal(Context c) {
        if (!has(c)) return;
        if (!Store.getBool(c, "calV4", false)) {
            syncAll(c);
            Store.putBool(c, "calV4", true);
            return;
        }
        for (Med m : Store.all(c)) if (m.evIds.isEmpty()) { syncMed(c, m); Store.save(c, m); }
        for (Appt a : Store.allAppts(c)) if (a.evId < 0) { syncAppt(c, a); Store.saveAppt(c, a); }
    }

    /** Events from the phone calendar for one Jalali year, keyed by day, excluding our own copies. */
    static HashMap<Integer, ArrayList<String>> yearEvents(Context c, int jy) {
        HashMap<Integer, ArrayList<String>> map = new HashMap<>();
        if (!has(c)) return map;
        int[] a = Jalali.j2g(jy, 1, 1), b = Jalali.j2g(jy + 1, 1, 1);
        long from = Jalali.millis(Jalali.key(a[0], a[1], a[2]), 0, 0);
        long to = Jalali.millis(Jalali.key(b[0], b[1], b[2]), 0, 0);
        try (Cursor cur = CalendarContract.Instances.query(c.getContentResolver(),
                new String[]{CalendarContract.Instances.BEGIN, CalendarContract.Instances.TITLE,
                        CalendarContract.Instances.DESCRIPTION}, from, to)) {
            if (cur == null) return map;
            Calendar cal = Calendar.getInstance();
            while (cur.moveToNext()) {
                String desc = cur.getString(2);
                if (desc != null && desc.contains(MARK)) continue;
                cal.setTimeInMillis(cur.getLong(0));
                int k = Jalali.key(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
                ArrayList<String> l = map.get(k);
                if (l == null) { l = new ArrayList<>(); map.put(k, l); }
                String t = cur.getString(1);
                l.add(t == null || t.isEmpty() ? "(بی‌عنوان)" : t);
            }
        } catch (Exception e) { /* no access or provider missing */ }
        return map;
    }
}
