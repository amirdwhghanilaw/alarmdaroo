package com.zangdaru.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class ApptEditActivity extends Activity {
    private static final int REQ_DATE = 1;
    private Ui.Pal p;
    private Appt ap;
    private int dateKey = 0, hour = 10, minute = 0;
    private EditText doctor, note;
    private TextView dateBtn, timeBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Ui.pal(this);
        int id = getIntent().getIntExtra("id", -1);
        ap = id >= 0 ? Store.getAppt(this, id) : null;
        if (ap != null) { dateKey = ap.dateKey; hour = ap.hour; minute = ap.minute; }
        else dateKey = getIntent().getIntExtra("date", 0);

        int pad = Ui.dp(this, 16);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad * 2);
        sv.addView(col);

        col.addView(Ui.topBar(this, ap == null ? "ثبت وقت پزشک" : "ویرایش وقت پزشک"), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));

        col.addView(Ui.text(this, "نام پزشک", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 18));
        doctor = field("مثلاً: دکتر احمدی", ap == null ? "" : ap.doctor);
        col.addView(doctor, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));

        col.addView(Ui.text(this, "روز مراجعه", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 16));
        dateBtn = Ui.button(this, "", p.soft, p.text);
        dateBtn.setOnClickListener(v -> {
            Intent i = new Intent(this, CalendarActivity.class);
            i.putExtra("mode", CalendarActivity.MODE_SINGLE);
            if (dateKey != 0) i.putExtra("dates", new int[]{dateKey});
            startActivityForResult(i, REQ_DATE);
        });
        col.addView(dateBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));

        col.addView(Ui.text(this, "ساعت مراجعه", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 16));
        timeBtn = Ui.button(this, "", p.soft, p.text);
        timeBtn.setOnClickListener(v -> TimeDialog.show(this, hour, minute, (hh, mm) -> {
            hour = hh;
            minute = mm;
            refresh();
        }));
        col.addView(timeBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));

        col.addView(Ui.text(this, "توضیح (اختیاری)", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 16));
        note = field("مثلاً: آدرس مطب، آزمایش‌ها را ببرم", ap == null ? "" : ap.note);
        col.addView(note, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));

        TextView info = Ui.text(this, "🔔 زنگ یادآوری: ۲۴ ساعت قبل و ۲ ساعت قبل از وقت مراجعه", 16, p.text, false);
        info.setBackground(Ui.box(this, p.soft, 16));
        info.setPadding(pad, pad, pad, pad);
        col.addView(info, Ui.lp(this, Ui.MATCH, Ui.WRAP, 18));

        TextView save = Ui.button(this, "💾  ذخیره", 0xFF2E9E5B, Color.WHITE);
        save.setTextSize(22);
        save.setOnClickListener(v -> save());
        col.addView(save, Ui.lp(this, Ui.MATCH, Ui.dp(this, 66), 22));
        if (ap != null) {
            TextView test = Ui.button(this, "🔔 آزمایش زنگ وقت پزشک (۱۰ ثانیه دیگر)", p.soft, p.text);
            test.setOnClickListener(v -> {
                Alarms.setAt(this, System.currentTimeMillis() + 10000, Alarms.apptPi(this, ap.id, 1));
                toast("۱۰ ثانیه‌ی دیگر زنگ می‌خورد");
            });
            col.addView(test, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
            TextView del = Ui.button(this, "🗑  حذف", 0xFFD32F2F, Color.WHITE);
            del.setOnClickListener(v -> confirmDelete());
            col.addView(del, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        }
        refresh();
        Ui.apply(this, sv);
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextSize(22);
        e.setTextColor(p.text);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setSingleLine(true);
        e.setBackground(Ui.box(this, Color.WHITE, 14));
        int q = Ui.dp(this, 14);
        e.setPadding(q, q, q, q);
        return e;
    }

    private void refresh() {
        dateBtn.setText(dateKey == 0 ? "📅  انتخاب از تقویم" : "📅  " + Jalali.fmtFull(dateKey));
        timeBtn.setText("🕐  " + Jalali.fa(Ui.hm(hour, minute)));
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req == REQ_DATE && res == RESULT_OK && d != null) {
            int[] a = d.getIntArrayExtra("dates");
            if (a != null && a.length > 0) { dateKey = a[0]; refresh(); }
        }
    }

    private void save() {
        String n = doctor.getText().toString().trim();
        if (n.isEmpty()) { toast("لطفاً نام پزشک را بنویسید"); return; }
        if (dateKey == 0) { toast("روز مراجعه را از تقویم انتخاب کنید"); return; }
        if (Jalali.millis(dateKey, hour, minute) <= System.currentTimeMillis()) {
            toast("زمان مراجعه باید در آینده باشد");
            return;
        }
        Appt a = ap != null ? ap : new Appt();
        if (ap == null) a.id = Store.nextApptId(this);
        else Alarms.cancelAppt(this, a.id);
        a.doctor = n;
        a.note = note.getText().toString().trim();
        a.dateKey = dateKey;
        a.hour = hour;
        a.minute = minute;
        CalSync.syncAppt(this, a);
        Store.saveAppt(this, a);
        Alarms.scheduleAppt(this, a);
        toast("ذخیره شد ✅");
        finish();
    }

    private void confirmDelete() {
        Ui.show(new AlertDialog.Builder(this)
                .setMessage("این وقت پزشک حذف شود؟")
                .setPositiveButton("بله، حذف شود", (dlg, w) -> {
                    Alarms.cancelAppt(this, ap.id);
                    CalSync.delete(this, ap.evId);
                    Store.removeAppt(this, ap.id);
                    finish();
                })
                .setNegativeButton("نه", null));
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
