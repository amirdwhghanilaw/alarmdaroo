package com.zangdaru.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class AboutActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.Pal p = Ui.pal(this);
        int pad = Ui.dp(this, 16);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad * 2);
        sv.addView(col);
        col.addView(Ui.topBar(this, "درباره برنامه"), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        top.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 120), Ui.dp(this, 120)));
        top.addView(Ui.text(this, "زنگ دارو", 32, p.primary, true));
        col.addView(top, Ui.lp(this, Ui.MATCH, Ui.WRAP, 14));

        col.addView(card(p, "📝  معرفی", getString(R.string.about_intro)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 16));
        col.addView(card(p, "🎯  هدف از ساخت", getString(R.string.about_goal)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 14));
        col.addView(card(p, "✍️  سازنده", getString(R.string.about_creator)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 14));
        Ui.apply(this, sv);
    }

    private LinearLayout card(Ui.Pal p, String title, String body) {
        int pad = Ui.dp(this, 16);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.box(this, p.soft, 20));
        c.setPadding(pad, pad, pad, pad);
        c.addView(Ui.text(this, title, 20, p.primary, true));
        TextView t = Ui.text(this, body, 19, p.text, false);
        t.setLineSpacing(0, 1.3f);
        c.addView(t, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));
        return c;
    }
}
