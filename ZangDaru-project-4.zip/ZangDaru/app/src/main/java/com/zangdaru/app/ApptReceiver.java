package com.zangdaru.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ApptReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        if (Alarms.ACT_APPT_OK.equals(in.getAction())) {
            Alarms.dismiss(c, in.getIntExtra("nid", 0));
            return;
        }
        Appt a = Store.getAppt(c, in.getIntExtra("appt", -1));
        if (a == null) return;
        Alarms.ringAppt(c, a, in.getIntExtra("which", 0));
    }
}
