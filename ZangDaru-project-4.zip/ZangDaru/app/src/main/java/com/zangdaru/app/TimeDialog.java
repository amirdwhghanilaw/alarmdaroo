package com.zangdaru.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

/** Dialogs where the hour and minute can be typed, and where a time can be repeated every N hours. */
final class TimeDialog {
    interface Callback { void onTime(int h, int m); }

    interface ListCallback { void onTimes(ArrayList<String> times); }

    /** Reads a number typed with English, Persian or Arabic digits; -1 if invalid. */
    static int num(String s) {
        if (s == null) return -1;
        StringBuilder sb = new StringBuilder();
        for (char ch : s.trim().toCharArray()) {
            if (ch >= '\u06F0' && ch <= '\u06F9') sb.append((char) ('0' + (ch - '\u06F0')));
            else if (ch >= '\u0660' && ch <= '\u0669') sb.append((char) ('0' + (ch - '\u0660')));
            else if (ch >= '0' && ch <= '9') sb.append(ch);
            else return -1;
        }
        if (sb.length() == 0) return -1;
        try {
            return Integer.parseInt(sb.toString());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static EditText numField(Activity a, Ui.Pal p, String value, int maxLen, String hint) {
        EditText e = new EditText(a);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLen)});
        e.setText(value);
        e.setHint(hint);
        e.setTextSize(32);
        e.setTextColor(p.text);
        e.setGravity(Gravity.CENTER);
        e.setSelectAllOnFocus(true);
        e.setSingleLine(true);
        e.setBackground(Ui.box(a, p.soft, 14));
        int q = Ui.dp(a, 8);
        e.setPadding(q, q, q, q);
        return e;
    }

    /** "08 : 30" row, always left-to-right like a clock; the two fields are returned in out[]. */
    private static LinearLayout hmRow(Activity a, Ui.Pal p, int h, int m, EditText[] out) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        out[0] = numField(a, p, String.format(Locale.US, "%02d", h), 2, "ساعت");
        out[1] = numField(a, p, String.format(Locale.US, "%02d", m), 2, "دقیقه");
        TextView colon = Ui.text(a, ":", 34, p.text, true);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        cl.setMargins(Ui.dp(a, 10), 0, Ui.dp(a, 10), 0);
        row.addView(out[0], new LinearLayout.LayoutParams(Ui.dp(a, 90), Ui.WRAP));
        row.addView(colon, cl);
        row.addView(out[1], new LinearLayout.LayoutParams(Ui.dp(a, 90), Ui.WRAP));
        return row;
    }

    /** Type hour and minute, or tap "انتخاب با ساعت" to use the clock dial. */
    static void show(final Activity a, int h, int m, final Callback cb) {
        final Ui.Pal p = Ui.pal(a);
        int pad = Ui.dp(a, 20);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        TextView hint = Ui.text(a, "ساعت و دقیقه را بنویسید\n(ساعت ۰ تا ۲۳ ، دقیقه ۰ تا ۵۹)", 16, p.text, false);
        hint.setGravity(Gravity.CENTER);
        box.addView(hint, Ui.lp(a, Ui.MATCH, Ui.WRAP, 0));
        final EditText[] f = new EditText[2];
        box.addView(hmRow(a, p, h, m, f), Ui.lp(a, Ui.MATCH, Ui.WRAP, 14));

        final AlertDialog dlg = Ui.show(new AlertDialog.Builder(a)
                .setView(box)
                .setPositiveButton("تأیید", null)
                .setNeutralButton("انتخاب با ساعت", null)
                .setNegativeButton("لغو", null));
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            int hh = num(f[0].getText().toString()), mm = num(f[1].getText().toString());
            if (hh < 0 || hh > 23 || mm < 0 || mm > 59) {
                Toast.makeText(a, "ساعت یا دقیقه درست نیست", Toast.LENGTH_SHORT).show();
                return;
            }
            dlg.dismiss();
            cb.onTime(hh, mm);
        });
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
            int hh = num(f[0].getText().toString()), mm = num(f[1].getText().toString());
            if (hh < 0 || hh > 23) hh = 8;
            if (mm < 0 || mm > 59) mm = 0;
            dlg.dismiss();
            new TimePickerDialog(a, (view, h2, m2) -> cb.onTime(h2, m2), hh, mm, true).show();
        });
        f[0].requestFocus();
        dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

    /** start + k*n hours for as long as it stays inside one 24-hour cycle. */
    static ArrayList<String> generate(int h, int m, int n) {
        ArrayList<String> l = new ArrayList<>();
        int start = h * 60 + m;
        for (int k = 0; k * n < 24; k++) {
            int t = (start + k * n * 60) % 1440;
            l.add(Ui.hm(t / 60, t % 60));
        }
        return l;
    }

    /** Start time + "every N hours" (1 to 24) -> the list of times of the day. */
    static void showRepeat(final Activity a, final ListCallback cb) {
        final Ui.Pal p = Ui.pal(a);
        int pad = Ui.dp(a, 20);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);

        box.addView(Ui.text(a, "از چه ساعتی شروع شود؟", 17, p.text, true), Ui.lp(a, Ui.WRAP, Ui.WRAP, 0));
        final EditText[] f = new EditText[2];
        box.addView(hmRow(a, p, 8, 0, f), Ui.lp(a, Ui.MATCH, Ui.WRAP, 8));
        box.addView(Ui.text(a, "هر چند ساعت یک بار؟ (۱ تا ۲۴)", 17, p.text, true), Ui.lp(a, Ui.WRAP, Ui.WRAP, 16));
        final EditText ei = numField(a, p, "4", 2, "۱ تا ۲۴");
        box.addView(ei, Ui.lp(a, Ui.dp(a, 110), Ui.WRAP, 8));
        final TextView preview = Ui.text(a, "", 17, p.primary, true);
        preview.setLineSpacing(0, 1.2f);
        box.addView(preview, Ui.lp(a, Ui.MATCH, Ui.WRAP, 14));
        box.addView(Ui.text(a, "ساعت‌های فعلی این دارو با ساعت‌های بالا جایگزین می‌شوند.", 14, p.text, false),
                Ui.lp(a, Ui.MATCH, Ui.WRAP, 8));

        final Runnable refresh = () -> {
            int hh = num(f[0].getText().toString()), mm = num(f[1].getText().toString());
            int n = num(ei.getText().toString());
            if (hh < 0 || hh > 23 || mm < 0 || mm > 59 || n < 1 || n > 24) {
                preview.setText("");
                return;
            }
            StringBuilder sb = new StringBuilder("ساعت‌ها: ");
            ArrayList<String> l = generate(hh, mm, n);
            for (int i = 0; i < l.size(); i++) {
                if (i > 0) sb.append(" ، ");
                sb.append(Jalali.fa(l.get(i)));
            }
            preview.setText(sb.toString());
        };
        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int af) { }
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { refresh.run(); }
        };
        f[0].addTextChangedListener(tw);
        f[1].addTextChangedListener(tw);
        ei.addTextChangedListener(tw);
        refresh.run();

        final AlertDialog dlg = Ui.show(new AlertDialog.Builder(a)
                .setTitle("🔁 تکرار هر چند ساعت")
                .setView(box)
                .setPositiveButton("ساخت ساعت‌ها", null)
                .setNegativeButton("لغو", null));
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            int hh = num(f[0].getText().toString()), mm = num(f[1].getText().toString());
            int n = num(ei.getText().toString());
            if (hh < 0 || hh > 23 || mm < 0 || mm > 59) {
                Toast.makeText(a, "ساعت یا دقیقه درست نیست", Toast.LENGTH_SHORT).show();
                return;
            }
            if (n < 1 || n > 24) {
                Toast.makeText(a, "تعداد ساعت باید بین ۱ تا ۲۴ باشد", Toast.LENGTH_SHORT).show();
                return;
            }
            dlg.dismiss();
            cb.onTimes(generate(hh, mm, n));
        });
        dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }
}
